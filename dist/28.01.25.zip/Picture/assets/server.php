<?php
echo var_dump($_FILES);